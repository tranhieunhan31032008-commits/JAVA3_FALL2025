package poly.com.controller;

import java.io.IOException;
import java.util.Date;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/save")
public class SaveServlet extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	req.getRequestDispatcher("/save.jsp").forward(req, resp);
}
@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	Staff bean = new Staff();
    try {
        // Configure date converter: pattern MM/dd/yyyy
        DateConverter dtc = new DateConverter();
        dtc.setPattern("dd/MM/yyyy");
        ConvertUtils.register(dtc, Date.class);

        // populate
        BeanUtils.populate(bean, req.getParameterMap());

        // kiểm tra kết quả (log ra console)
        System.out.println("Fullname: " + bean.getFullname());
        System.out.println("Birthday: " + bean.getBirthday());
        System.out.println("Gender: " + bean.isGender());
        System.out.println("Hobbies: " + (bean.getHobbies() == null ? "null" : String.join(",", bean.getHobbies())));
        System.out.println("Country: " + bean.getCountry());
        System.out.println("Salary: " + bean.getSalary());

        req.setAttribute("staff", bean);
        req.getRequestDispatcher("/save-result.jsp").forward(req, resp);

    } catch (Exception e) {
        e.printStackTrace();
        resp.getWriter().println("Error: " + e.getMessage());
    }
	}
}
