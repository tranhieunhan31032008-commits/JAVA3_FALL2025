package poly.com.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Paths;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
@WebServlet("/upload")
@MultipartConfig( 
		fileSizeThreshold = 1024 * 1024, // 1MB
        maxFileSize = 1024 * 1024 * 10,  // 10MB
        maxRequestSize = 1024 * 1024 * 50 // 50MB
        )
public class Bai4Controller extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	req.getRequestDispatcher("/upload.jsp").forward(req, resp);
}

@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	Part part = req.getPart("photo");

    if (part == null || part.getSize() == 0) {
        req.setAttribute("message", "Không có file được chọn!");
        req.getRequestDispatcher("/upload.jsp").forward(req, resp);
        return;
    }

    // Lấy tên file
    String fileName = part.getSubmittedFileName();

    // Đường dẫn lưu file (THƯ MỤC TĨNH)
    String relativePath = "/static/file"; 
    String absolutePath = req.getServletContext().getRealPath(relativePath);

    File dir = new File(absolutePath);
    if (!dir.exists()) {
        dir.mkdirs();  // tạo nếu chưa có
    }

    // Tạo tên file mới tránh trùng
    String savedName = System.currentTimeMillis() + "_" + fileName;
    File savedFile = new File(dir, savedName);

    // Ghi file
    try (InputStream in = part.getInputStream();
         FileOutputStream out = new FileOutputStream(savedFile)) {

        byte[] buffer = new byte[1024];
        int length;
        while ((length = in.read(buffer)) > 0) {
            out.write(buffer, 0, length);
        }
    }

    // Đường dẫn để hiển thị trên web
    String webPath = req.getContextPath() + relativePath + "/" + savedName;

    // Gửi sang JSP
    req.setAttribute("message", "Upload thành công!");
    req.setAttribute("imagePath", webPath);

    req.getRequestDispatcher("/upload.jsp").forward(req, resp);
}
}
