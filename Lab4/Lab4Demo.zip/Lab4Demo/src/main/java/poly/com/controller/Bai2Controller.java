package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet({"/calculate/add", "/calculate/sub"})
public class Bai2Controller extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	 req.setAttribute("message", "Nhập số và chọn phép tính");
     req.getRequestDispatcher("/calculate.jsp").forward(req, resp);
}
@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	String a = req.getParameter("a");
    String b = req.getParameter("b");
    String path = req.getServletPath();

    try {
        double da = Double.parseDouble(a);
        double db = Double.parseDouble(b);
        double c;
        if (path.endsWith("/add")) {
            c = da + db;
            req.setAttribute("message", a + " + " + b + " = " + c);
        } else {
            c = da - db;
            req.setAttribute("message", a + " - " + b + " = " + c);
        }
    } catch (NumberFormatException e) {
        req.setAttribute("message", "Vui lòng nhập số hợp lệ cho a và b");
    }
    req.getRequestDispatcher("/calculate.jsp").forward(req, resp);

	}
}
