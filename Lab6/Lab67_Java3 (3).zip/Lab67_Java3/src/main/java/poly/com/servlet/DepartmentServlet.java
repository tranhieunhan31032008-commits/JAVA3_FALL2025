package poly.com.servlet;

import poly.com.dao.DepartmentDAO;
import poly.com.dao.DepartmentDAOImpl;
import poly.com.model.Department;
import org.apache.commons.beanutils.BeanUtils;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet({
    "/department",
    "/department/edit/*",
    "/department/create",
    "/department/update",
    "/department/delete",
    "/department/reset"
})

public class DepartmentServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        Department form = new Department();

        try {
            BeanUtils.populate(form, req.getParameterMap());
        } catch (Exception e) {
            e.printStackTrace();
        }

        DepartmentDAO dao = new DepartmentDAOImpl();
        String path = req.getServletPath();

        if (path.contains("edit")) {
            String id = req.getPathInfo().substring(1);
            form = dao.findById(id);

        } else if (path.contains("create")) {
            dao.create(form);
            form = new Department();

        } else if (path.contains("update")) {
            dao.update(form);

        } else if (path.contains("delete")) {
            dao.deleteById(form.getId());
            form = new Department();

        } else {
            form = new Department();
        }

        req.setAttribute("item", form);
        req.setAttribute("list", dao.findAll());

        req.getRequestDispatcher("/department.jsp").forward(req, resp);
    }
}
