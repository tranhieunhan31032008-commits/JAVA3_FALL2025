package poly.com.dao;

import poly.com.model.Employee;
import poly.com.utils.Jdbc;
import java.sql.*;
import java.util.*;

public class EmployeeDAOImpl implements EmployeeDAO {

    @Override
    public List<Employee> findAll() {
        String sql = "SELECT * FROM Employees";
        List<Employee> list = new ArrayList<>();

        try {
            ResultSet rs = Jdbc.executeQuery(sql);
            while (rs.next()) {
                Employee e = new Employee();
                e.setId(rs.getString("Id"));
                e.setName(rs.getString("Name"));
                e.setEmail(rs.getString("Email"));
                e.setPhone(rs.getString("Phone"));
                e.setSalary(rs.getDouble("Salary"));
                e.setDepartmentId(rs.getString("DepartmentId"));
                e.setPosition(rs.getString("Position"));
                list.add(e);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    @Override
    public Employee findById(String id) {
        String sql = "SELECT * FROM Employees WHERE Id=?";
        try {
            ResultSet rs = Jdbc.executeQuery(sql, id);
            if (rs.next()) {
                Employee e = new Employee();
                e.setId(rs.getString("Id"));
                e.setName(rs.getString("Name"));
                e.setEmail(rs.getString("Email"));
                e.setPhone(rs.getString("Phone"));
                e.setSalary(rs.getDouble("Salary"));
                e.setDepartmentId(rs.getString("DepartmentId"));
                e.setPosition(rs.getString("Position"));
                return e;
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        throw new RuntimeException("Employee not found");
    }

    @Override
    public void create(Employee e) {
        String sql = "INSERT INTO Employees(Id, Name, Email, Phone, Salary, DepartmentId, Position) VALUES(?,?,?,?,?,?,?)";
        try {
            Jdbc.executeUpdate(sql, e.getId(), e.getName(), e.getEmail(), e.getPhone(), e.getSalary(), e.getDepartmentId(), e.getPosition());
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void update(Employee e) {
        String sql = "UPDATE Employees SET Name=?, Email=?, Phone=?, Salary=?, DepartmentId=?, Position=? WHERE Id=?";
        try {
            Jdbc.executeUpdate(sql, e.getName(), e.getEmail(), e.getPhone(), e.getSalary(), e.getDepartmentId(), e.getPosition(), e.getId());
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void deleteById(String id) {
        String sql = "DELETE FROM Employees WHERE Id=?";
        try {
            Jdbc.executeUpdate(sql, id);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}



