package poly.com.dao;

import java.util.List;
import poly.com.model.*;

public interface DepartmentDAO {
    List<Department> findAll();
    Department findById(String id);
    void create(Department entity);
    void update(Department entity);
    void deleteById(String id);
}
