package poly.com.dao;

import java.util.List;
import poly.com.model.*;

public interface EmployeeDAO {
    List<Employee> findAll();
    Employee findById(String id);
    void create(Employee entity);
    void update(Employee entity);
    void deleteById(String id);
}



