package poly.com.servlet;

import poly.com.dao.EmployeeDAO;
import poly.com.dao.EmployeeDAOImpl;
import poly.com.dao.DepartmentDAO;
import poly.com.dao.DepartmentDAOImpl;
import poly.com.model.Employee;
import org.apache.commons.beanutils.BeanUtils;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet({
    "/employee",
    "/employee/edit/*",
    "/employee/create",
    "/employee/update",
    "/employee/delete",
    "/employee/reset"
})

public class EmployeeServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        Employee form = new Employee();

        try {
            BeanUtils.populate(form, req.getParameterMap());
        } catch (Exception e) {
            e.printStackTrace();
        }

        EmployeeDAO dao = new EmployeeDAOImpl();
        DepartmentDAO deptDao = new DepartmentDAOImpl();
        String path = req.getServletPath();

        if (path.contains("edit")) {
            String id = req.getPathInfo().substring(1);
            form = dao.findById(id);

        } else if (path.contains("create")) {
            dao.create(form);
            form = new Employee();

        } else if (path.contains("update")) {
            dao.update(form);

        } else if (path.contains("delete")) {
            dao.deleteById(form.getId());
            form = new Employee();

        } else {
            form = new Employee();
        }

        req.setAttribute("item", form);
        req.setAttribute("list", dao.findAll());
        req.setAttribute("departments", deptDao.findAll());

        req.getRequestDispatcher("/employee.jsp").forward(req, resp);
    }
}



