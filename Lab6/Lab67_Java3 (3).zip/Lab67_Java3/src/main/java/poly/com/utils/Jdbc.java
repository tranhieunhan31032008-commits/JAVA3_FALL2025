package poly.com.utils;

import java.sql.*;

public class Jdbc {
    private static String url = "jdbc:sqlserver://localhost:1433;databaseName=Lab6_Java3;encrypt=false";
    private static String user = "sa";
    private static String pass = "123";

    static {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static PreparedStatement getStmt(String sql, Object... args) throws Exception {
        Connection conn = DriverManager.getConnection(url, user, pass);
        PreparedStatement stmt = conn.prepareStatement(sql);

        for (int i = 0; i < args.length; i++) {
            stmt.setObject(i + 1, args[i]);
        }

        return stmt;
    }

    public static ResultSet executeQuery(String sql, Object... args) {
        try {
            PreparedStatement stmt = getStmt(sql, args);
            return stmt.executeQuery();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static int executeUpdate(String sql, Object... args) {
        try {
            PreparedStatement stmt = getStmt(sql, args);
            Connection conn = stmt.getConnection();

            try (stmt; conn) {
                return stmt.executeUpdate();
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
