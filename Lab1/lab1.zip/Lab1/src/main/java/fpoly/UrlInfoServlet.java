package fpoly;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/UrlInfoServlet")
public class UrlInfoServlet extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	String url = req.getRequestURL().toString(); // Lấy URL
	String uri = req.getRequestURI();            // Lấy URI
	String queryString = req.getQueryString();   // Lấy Query String
	String servletPath = req.getServletPath();   // Lấy Servlet Path
	String contextPath = req.getContextPath();   // Lấy Context Path
	String pathInfo = req.getPathInfo();         // Lấy Path Info
	String method = req.getMethod();             // Lấy Method (GET, POST)

	// Xuất các thông tin ra trình duyệt
	resp.getWriter().println("URL: " + url );
	resp.getWriter().println("URI: " + uri );
	resp.getWriter().println("Query String: " + queryString );
	resp.getWriter().println("Servlet Path: " + servletPath );
	resp.getWriter().println("Context Path: " + contextPath );
	resp.getWriter().println("Path Info: " + pathInfo );
	resp.getWriter().println("Method: " + method );
}
}
