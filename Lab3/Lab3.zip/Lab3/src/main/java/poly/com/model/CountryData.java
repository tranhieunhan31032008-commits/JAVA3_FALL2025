package poly.com.model;

import java.util.ArrayList;
import java.util.List;

public class CountryData {

    public static List<Country> list = new ArrayList<>();

    static {
        list.add(new Country("VN", "Việt Nam"));
        list.add(new Country("CN", "Trung Quốc"));
        list.add(new Country("US", "Hoa Kỳ"));
        list.add(new Country("JP", "Nhật Bản"));
    }

    public static List<Country> getCountries() {
        return list;
    }
}
