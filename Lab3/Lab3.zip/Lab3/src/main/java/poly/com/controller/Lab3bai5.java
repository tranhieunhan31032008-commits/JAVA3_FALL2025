package poly.com.controller;

import java.io.IOException;
import java.util.ArrayList;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.model.ItemData;
import poly.com.model.ViewItemData;

@WebServlet("/lab3bai5")
public class Lab3bai5 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// req.setAttribute("lan", 10000000);

	/*
	 * ArrayList<String> danhsach = new ArrayList<String>(); danhsach.add("Cần");
	 * danhsach.add("Cù"); danhsach.add("Siêng"); danhsach.add("Năng");
	 * req.setAttribute("ds", danhsach);
	 */
	ArrayList<ItemData> items = ViewItemData.getItems();
	getServletContext().setAttribute("items", items);

	req.setAttribute("items", items);
	req.getRequestDispatcher("listproducts.jsp").forward(req, resp);
    }
}
