package poly.com.controller;

import java.io.IOException;
import java.util.Map;
import java.util.HashMap;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/FormServlet")
public class FormServlet extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	Map<String, Object> map = new HashMap<>();
    map.put("fullname", "Trần Hiểu Nhân");
    map.put("gender", true);        // true = Male
    map.put("country", "VN");

    req.setAttribute("user", map);
    req.setAttribute("editable", true);  // Cho phép chỉnh sửa → disable Create

    req.getRequestDispatcher("/form.jsp").forward(req, resp);
}

@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	req.setCharacterEncoding("UTF-8");
	String fullname = req.getParameter("fullname");
    String genderStr = req.getParameter("gender");
    String country = req.getParameter("country");

    // Xử lý gender
    boolean gender = "true".equals(genderStr);

    // Tạo Map từ dữ liệu POST
    Map<String, Object> map = new HashMap<>();
    map.put("fullname", fullname != null ? fullname : "");
    map.put("gender", gender);
    map.put("country", country != null ? country : "");

    // Cập nhật lại request
    req.setAttribute("user", map);
    req.setAttribute("editable", false); // Đã submit → cho phép Create, readonly fullname

    req.getRequestDispatcher("/form.jsp").forward(req, resp);
	}
}
