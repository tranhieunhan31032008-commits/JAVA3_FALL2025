package poly.com.bean;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import poly.com.bean.User;  // ĐÃ THÊM

@WebServlet("/FormServlet1")
public class FormServlet1 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {

        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null) {
            user = new User();
            user.setFullname("Trần Hiểu Nhân");
            user.setGender(true);
            user.setCountry("VN");
            session.setAttribute("user", user);
            req.setAttribute("editable", true);
        } else {
            req.setAttribute("editable", false);
        }

        req.setAttribute("user", user);
        req.getRequestDispatcher("/form1.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        HttpSession session = req.getSession();

        String action = req.getParameter("action");
        User user = new User();

        if ("create".equals(action)) {
            user.setFullname("");
            user.setGender(true);
            user.setCountry("VN");
            req.setAttribute("editable", true);

        } else if ("update".equals(action)) {
            user.setFullname(req.getParameter("fullname"));
            user.setGender("true".equals(req.getParameter("gender")));
            user.setCountry(req.getParameter("country"));
            req.setAttribute("editable", false);
        }

        session.setAttribute("user", user);
        req.setAttribute("user", user);

        req.getRequestDispatcher("/form1.jsp").forward(req, resp);
    }
}